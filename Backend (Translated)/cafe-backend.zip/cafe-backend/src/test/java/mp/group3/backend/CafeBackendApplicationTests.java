package mp.group3.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
